<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Create_Address</name>
   <tag></tag>
   <elementGuidId>2dddc7f0-4ed3-410c-9b01-4d69385bcd2c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[value=&quot;Create Address&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>input[value=&quot;Create Address&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1609271501486</value>
   </webElementProperties>
</WebElementEntity>
